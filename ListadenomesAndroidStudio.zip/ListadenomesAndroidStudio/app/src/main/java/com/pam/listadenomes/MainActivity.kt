package com.pam.listadenomes

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nomes = listOf("Guto", "Mari", "Juanzito", "Hyo", "Craudete")
        val listView = findViewById<ListView>(R.id.Lista)

        listView.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            nomes
        ) {

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)

                textView.textSize = 24f
                textView.setTextColor(Color.BLACK)

                return view
            }
        }

        listView.adapter = adapter
    }
}